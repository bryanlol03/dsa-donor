package utility;

import java.awt.Toolkit;

/**
 *
 * @author User
 */
public class MessageUI {

    public static void displayExitMessage() {
        displayLogo();
        System.out.println("\nThank you for supporting our charity organization !");
    }
    
    public static void displayInvalidInputMessage(){
    Toolkit.getDefaultToolkit().beep();
    System.out.println("Invalid Input ! Please enter again ...");
    }

    public static void displayNotFoundMessage() {
        Toolkit.getDefaultToolkit().beep();//alert sound
        System.out.println("Record not found ! Please enter again ...");
    }

    public static void displaySuccessfulAddMessage() {
        System.out.println("Successfully Added !");
    }

    public static void displayUnsuccessfulAddMessage() {
        Toolkit.getDefaultToolkit().beep();
        System.out.println("Unsuccessful Added ! :(");
    }

    public static void displaySuccessfulDeleteMessage() {
        System.out.println("Successfully Deleted !");
    }

    public static void displayUnsuccessfulDeleteMessage() {
        Toolkit.getDefaultToolkit().beep();
        System.out.println("Unsuccessful Deleted ! :(");
    }

    public static void displaySuccessfulAmendMessage() {
        System.out.println("Successfully Amend !");
    }

    public static void displayUnsuccessfulAmendMessage() {
        Toolkit.getDefaultToolkit().beep();
        System.out.println("Unsuccessfully Amend !:( ");
    }

    public static void displayUpdateSuccessfulMessage() {
        System.out.println("Update Successful !");
    }

    public static void displayUpdateUnsuccessfulMessage() {
        Toolkit.getDefaultToolkit().beep();
        System.out.println("Update Unsuccessful ! :( ");
    }

    public static void displayInvalidChoiceMessage() {
        Toolkit.getDefaultToolkit().beep();
        System.out.println("Invalid Choice please enter again ! :(");
    }

    public static void displayAssginSuccessfulMessage() {
        System.out.println("Assign Successful!");
    }

    public static void displayAssignUnsuccessfulMessage() {
        Toolkit.getDefaultToolkit().beep();
        System.out.println("Assign Unsuccessful ! :(");
    }

    public static void displayWelcomeMsg() {
        System.out.println("Welcome to use the charity organization system !");
        displayLogo();
    }  

    private static void displayLogo() {
        System.out.println("     ____ ____  _   _    _    _     _ _   _  ");
        System.out.println("    / ___|  _ \\| | | |  / \\  | |   (_) |_| |__   ___  ");
        System.out.println("   | |  _| |_) | |_| | / _ \\ | |   | | __| '_ \\ / _ \\ ");
        System.out.println("   | |_| |  __/|  _  |/ ___ \\| |___| | |_| | | |  __/ ");
        System.out.println("    \\____|_|   |_| |_/_/   \\_\\_____|_|\\__|_| |_|\\___| ");
        System.out.println();
        System.out.println("          ___     ___     ___     ___ ");
        System.out.println("         /   \\   /   \\   /   \\   /   \\ ");
        System.out.println("        /     \\_/     \\_/     \\_/     \\_ ");
        System.out.println("       |                                  |");
        System.out.println("        \\___     ___     ___     ___     __/");
        System.out.println("            \\___/   \\___/   \\___/   \\___/\n");
    }

}
