package entity;

import adt.SortedDoublyLinkedList;
import adt.SortedLinkedListInterface;
import java.io.Serializable;
import java.util.Objects;

public class Donor implements Comparable<Donor>, Serializable {

    private static final long serialVersionUID = 1L;

    private String donorId;
    private String name;
    private String contactNo;
    private int donorAge;
    private char donorGender;
    private String donorType;
    private SortedLinkedListInterface<Donation> donations = new SortedDoublyLinkedList<>();

    public Donor() {
    }

    public Donor(String donorId, String name, String contactNo, int donorAge, char donorGender, String donorType) {
        this.donorId = donorId;
        this.name = name;
        this.contactNo = contactNo;
        this.donorAge = donorAge;
        this.donorGender = donorGender;
        this.donorType = donorType;
    }

    public char getDonorGender() {
        return donorGender;
    }

    public void setDonorGender(char donorGender) {
        this.donorGender = donorGender;
    }

    public int getDonorAge() {
        return donorAge;
    }

    public void setDonorAge(int donorAge) {
        if (donorAge <= 0) {
            throw new IllegalArgumentException("Age must be positive");
        }
        this.donorAge = donorAge;
    }

    public SortedLinkedListInterface<Donation> getDonations() {
        return donations;
    }

    public void setDonations(SortedLinkedListInterface<Donation> donations) {
        this.donations = donations;
    }

    public String getDonorId() {
        return donorId;
    }

    public void setDonorId(String donorId) {
        this.donorId = donorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        if (contactNo == null || contactNo.isEmpty()) {
            throw new IllegalArgumentException("Contact number cannot be null or empty");
        }
        this.contactNo = contactNo;
    }

    public String getDonorType() {
        return donorType;
    }

    public void setDonorType(String donorType) {
        this.donorType = donorType;
    }

    public void addDonation(Donation donation) {
        donations.add(donation);
    }

    public void deleteDonation(Donation donation) {
        donations.remove(donation);
    }

    public void updateDonation(Donation donation, Donation newDonation) {
        donations.replace(donation, newDonation);
    }

    @Override
    public String toString() {
        return String.format("%-7s %-10s %-15s %-5d %-7c %-10s",
                donorId, name, contactNo, donorAge, donorGender, donorType);
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.donorId);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Donor other = (Donor) obj;
        if (!Objects.equals(this.donorId, other.donorId)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Donor o) {
        return this.donorId.compareTo(o.donorId);
    }
}
