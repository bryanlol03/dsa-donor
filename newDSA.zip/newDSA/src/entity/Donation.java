package entity;

import adt.SortedDoublyLinkedList;

public class Donation implements Comparable<Donation> {

    private SortedDoublyLinkedList<Donor> donor;
    private String donationId;

    @Override
    public int compareTo(Donation o) {
        return this.donationId.compareTo(o.donationId);
    }
}
