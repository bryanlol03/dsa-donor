package adt;

import java.util.Iterator;

public interface SortedLinkedListInterface<T extends Comparable<T>> {

    Iterator<T> getIterator();

    public void display();

    public boolean add(T newEntry);

    public boolean replace(T oldEntry, T newEntry);

    public boolean remove(T anEntry);

    public boolean contains(T anEntry);
    public T getEntry(int anEntry);

    //public void clear();
    public int getNumberOfEntries();

    public boolean isEmpty();
    
    public boolean intersection(SortedLinkedListInterface<T> otherList);
}
