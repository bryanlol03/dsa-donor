package dao;

import adt.SortedDoublyLinkedList;
import adt.SortedLinkedListInterface;
import entity.Donation;

public class DonationInitializer {
      private boolean initialized;

    public SortedDoublyLinkedList<Donation> dList = new SortedDoublyLinkedList<>();

    public static SortedLinkedListInterface<Donation> initializeDonor() {
        SortedLinkedListInterface<Donation> dList = new SortedDoublyLinkedList<>();
       

        return dList;
    }

    public boolean isInitialized() {
        return initialized;
    }
}
