package dao;

import adt.*;
import entity.Donor;

/**
 *
 * @author User
 */
public class DonorInitializer {

    private boolean initialized;

    public SortedDoublyLinkedList<Donor> dList = new SortedDoublyLinkedList<>();

    public static SortedLinkedListInterface<Donor> initializeDonor() {
        SortedLinkedListInterface<Donor> dList = new SortedDoublyLinkedList<>();
        dList.add(new Donor("D0001", "BRYAN", "0101234567", 19, 'M', "Government"));   // Group 19-30
        dList.add(new Donor("D0002", "CHEESHUN", "0101234567", 20, 'M', "Private"));   // Group 19-30
        dList.add(new Donor("D0003", "JUNSHENG", "0101234567", 19, 'M', "Public"));    // Group 19-30
        dList.add(new Donor("D0004", "ZHENGHONG", "0101234567", 20, 'M', "Government"));// Group 19-30
        dList.add(new Donor("D0005", "YEESAM", "0101234567", 20, 'M', "Government"));   // Group 19-30
        dList.add(new Donor("D0006", "ALEX", "0101234567", 21, 'M', "Public"));         // Group 19-30
        dList.add(new Donor("D0007", "DERRICK", "0101234567", 21, 'M', "Private"));     // Group 19-30
        dList.add(new Donor("D0008", "SIMON", "0101234567", 21, 'M', "Government"));    // Group 19-30
        dList.add(new Donor("D0009", "ALI", "0101234567", 21, 'M', "Government"));      // Group 19-30
        dList.add(new Donor("D0010", "ABU", "0101234567", 21, 'M', "Government"));      // Group 19-30
        dList.add(new Donor("D0011", "SITI", "0107654321", 22, 'F', "Private"));        // Group 19-30
        dList.add(new Donor("D0012", "RAJ", "0102345678", 22, 'M', "Government"));      // Group 19-30
        dList.add(new Donor("D0013", "WEILING", "0108765432", 23, 'F', "Public"));      // Group 19-30
        dList.add(new Donor("D0014", "JOHN", "0103456789", 23, 'M', "Private"));        // Group 19-30
        dList.add(new Donor("D0015", "FARAH", "0109876543", 24, 'F', "Government"));    // Group 19-30
        dList.add(new Donor("D0016", "KUMAR", "0104567890", 24, 'M', "Public"));        // Group 19-30
        dList.add(new Donor("D0017", "CHENG", "0101230987", 25, 'M', "Private"));       // Group 19-30
        dList.add(new Donor("D0018", "MEI", "0102340987", 25, 'F', "Government"));      // Group 19-30
        dList.add(new Donor("D0019", "DANIEL", "0103450987", 26, 'M', "Public"));       // Group 19-30
        dList.add(new Donor("D0020", "ZARA", "0104560987", 26, 'F', "Private"));        // Group 19-30
        dList.add(new Donor("D0021", "AHMED", "0105670987", 27, 'M', "Government"));    // Group 19-30
        dList.add(new Donor("D0022", "LILY", "0106780987", 27, 'F', "Private"));        // Group 19-30
        dList.add(new Donor("D0023", "MARK", "0107890987", 28, 'M', "Public"));         // Group 19-30
        dList.add(new Donor("D0024", "AISYAH", "0108900987", 28, 'F', "Government"));   // Group 19-30
        dList.add(new Donor("D0025", "HAFIZ", "0109010987", 29, 'M', "Private"));       // Group 19-30
        dList.add(new Donor("D0026", "JOE", "0111234567", 31, 'M', "Public"));          // Group 31-40
        dList.add(new Donor("D0027", "FATIMAH", "0112345678", 32, 'F', "Government"));  // Group 31-40
        dList.add(new Donor("D0028", "GEORGE", "0113456789", 35, 'M', "Private"));      // Group 31-40
        dList.add(new Donor("D0029", "HELEN", "0114567890", 38, 'F', "Public"));        // Group 31-40
        dList.add(new Donor("D0030", "IQBAL", "0115678901", 40, 'M', "Government"));    // Group 31-40
        dList.add(new Donor("D0031", "MARIA", "0116789012", 41, 'F', "Private"));       // Group 41-50
        dList.add(new Donor("D0032", "KHALID", "0117890123", 45, 'M', "Public"));       // Group 41-50
        dList.add(new Donor("D0033", "SAMIRA", "0118901234", 48, 'F', "Government"));   // Group 41-50
        dList.add(new Donor("D0034", "TOM", "0119012345", 50, 'M', "Private"));         // Group 41-50

        return dList;
    }

    public boolean isInitialized() {
        return initialized;
    }
}
