package control;

import adt.SortedDoublyLinkedList;
import adt.SortedLinkedListInterface;
import boundry.DonorMaintenanceUI;
import dao.DonorInitializer;
import entity.Donor;
import java.sql.Timestamp;
import java.util.Iterator;
import utility.MessageUI;
import java.util.Scanner;

public class DonorMaintenance {

    private SortedLinkedListInterface<Donor> donorList = new SortedDoublyLinkedList<>();
    private DonorMaintenanceUI donorUI = new DonorMaintenanceUI();
    private DonorInitializer dI = new DonorInitializer();
    private Scanner scanner = new Scanner(System.in);

    public DonorMaintenance() {
        dI = new DonorInitializer();
        donorList = dI.initializeDonor();
    }

    public void runDonorMaintenance() {
        int choice = 0;

        do {
            choice = donorUI.getMenuChoice();
            switch (choice) {
                case 0:
                    MessageUI.displayExitMessage();
                    break;
                case 1:
                    addNewDonor();
                    break;
                case 2:
                    removeDonor();
                    break;
                case 3:
                    updateDonor();
                    break;
                case 4:
                    searchDonors();
                    break;
                case 5:
                    displayDonor();
                    break;
                case 6:
                    filterDonor();
                    break;
                case 7:
                    generateReport();
                    break;
                default:
                    MessageUI.displayInvalidChoiceMessage();
            }
        } while (choice != 0);

    }

    private void filterDonor() {
        while (true) {
            Timestamp dateTime = new Timestamp(System.currentTimeMillis());
            String newDateTime = dateTime.toString().substring(0, 16);
            System.out.println("    +========================================+");
            System.out.println("    |         Filter Donor Submenu           |");
            System.out.println("    |       Today is -> " + newDateTime + "     |");
            System.out.println("    +========================================+");
            System.out.println("    | 1. Filter by Age                       |");
            System.out.println("    | 2. Filter by Donation Frequency        |");
            System.out.println("    | 3. Filter by Newly Added               |");
            System.out.println("    | 4. Back to Main Menu                   |");
            System.out.println("    +----------------------------------------+\n");
            System.out.print("      Enter your choice --> ");

            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    filterAge();
                    break;
                case 2:
                    //filterByFrequency();
                    break;
                case 3:
                    compareRecord();
                    break;
                case 4:
                    runDonorMaintenance();
                    break; // Exit filter menu
                default:
                    MessageUI.displayInvalidChoiceMessage();
            }
        }
    }

    public void compareRecord() {//method to compare oldest and newest record
        filterByOldest();
        filterByNewlyAdded();
    }

    public void filterByOldest() {
        try {

            int oldestThreshold = 4;
            int totalDonors = donorList.getNumberOfEntries();

            if (totalDonors < oldestThreshold) {
                System.out.println("Not enough donors to filter the oldest. Not enough donors in the system.");
                return;
            }

            SortedDoublyLinkedList<Donor> oldestDonors = new SortedDoublyLinkedList<>();

            for (int i = 0; i <= oldestThreshold; i++) {
                Donor donor = donorList.getEntry(i);
                if (donor != null) {
                    oldestDonors.add(donor);
                }
            }

            if (oldestDonors.getNumberOfEntries() > 0) {
                System.out.println("\nOldest Donors:");
                displayDonorGroup(oldestDonors);
                System.out.println("\nThe above donors are the oldest members in the system.");
            } else {
                System.out.println("No oldest donors found. You are not able to view this filter.");
            }

        } catch (NullPointerException ex) {
            System.out.println("An error occurred while processing the oldest donors.");
        }
    }

    public void filterByNewlyAdded() {
        try {
            int newlyAddedThreshold = 6;
            int totalDonors = donorList.getNumberOfEntries();

            if (totalDonors < newlyAddedThreshold) {
                System.out.println("Not enough donors to filter newly added. No new members added.");
                return;
            }

            SortedDoublyLinkedList<Donor> newlyAddedDonors = new SortedDoublyLinkedList<>();

            for (int i = totalDonors - newlyAddedThreshold + 1; i <= totalDonors; i++) {
                Donor donor = donorList.getEntry(i);
                if (donor != null) {
                    newlyAddedDonors.add(donor);
                }
            }

            if (newlyAddedDonors.getNumberOfEntries() > 0) {
                System.out.println("\nNewly Added Donors:");
                displayDonorGroup(newlyAddedDonors);
                System.out.println("\nThe above donors are the most recently added members to the system.");
            } else {
                System.out.println("No newly added donors found. You are not able to view this filter.");
            }

        } catch (NullPointerException ex) {
            System.out.println("An error occurred while processing the newly added donors.");
        }
    }

    public void filterAge() {
        int minAge = donorUI.inputMinAge();
        int maxAge = donorUI.inputMaxAge();

        if (minAge > maxAge) {
            System.out.println("Minimum age cannot be greater than maximum age. Please try again.!\n");
            return;
        }

        filterDonorsByAge(minAge, maxAge);
        calculateAverageAgeByGroup();
    }

    public void filterDonorsByAge(int minAge, int maxAge) {
        SortedDoublyLinkedList<Donor> youngestDonors = new SortedDoublyLinkedList<>();
        SortedDoublyLinkedList<Donor> oldestDonors = new SortedDoublyLinkedList<>();

        int minGroupAge = Integer.MAX_VALUE;
        int maxGroupAge = Integer.MIN_VALUE;

        Iterator<Donor> iterator = donorList.getIterator();
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            int donorAge = donor.getDonorAge();

            if (donorAge >= minAge && donorAge <= maxAge) {
                if (donorAge < minGroupAge) {
                    minGroupAge = donorAge;
                    youngestDonors = new SortedDoublyLinkedList<>();
                    youngestDonors.add(donor);
                } else if (donorAge == minGroupAge) {
                    youngestDonors.add(donor);
                }

                if (donorAge > maxGroupAge) {
                    maxGroupAge = donorAge;
                    oldestDonors = new SortedDoublyLinkedList<>();
                    oldestDonors.add(donor);
                } else if (donorAge == maxGroupAge) {
                    oldestDonors.add(donor);
                }
            }
        }

        if (youngestDonors.getNumberOfEntries() > 0) {
            System.out.println("\nYoungest Donors (Age: " + minGroupAge + "):");
            displayDonorGroup(youngestDonors);
        } else {
            System.out.println("No youngest donors found within the specified age range.");
        }

        if (oldestDonors.getNumberOfEntries() > 0) {
            System.out.println("\nOldest Donors (Age: " + maxGroupAge + "):");
            displayDonorGroup(oldestDonors);
        } else {
            System.out.println("No oldest donors found within the specified age range.");
        }
    }

    public void calculateAverageAgeByGroup() {

        int[] ageGroupSums = new int[3];
        int[] ageGroupCounts = new int[3];

        Iterator<Donor> iterator = donorList.getIterator();
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            int age = donor.getDonorAge();

            if (age >= 19 && age <= 30) {
                ageGroupSums[0] += age;
                ageGroupCounts[0]++;
            } else if (age >= 31 && age <= 40) {
                ageGroupSums[1] += age;
                ageGroupCounts[1]++;
            } else if (age >= 41 && age <= 50) {
                ageGroupSums[2] += age;
                ageGroupCounts[2]++;
            }
        }

        String[] groupNames = {"19-30", "31-40", "41-50"};
        double[] averages = new double[3];

        int count = 0;
        for (int i = 0; i < ageGroupSums.length; i++) {
            count++;
            if (ageGroupCounts[i] > 0) {
                averages[i] = (double) ageGroupSums[i] / ageGroupCounts[i];
                System.out.printf("%d) Average age for group %s : %.3f%n", count, groupNames[i], averages[i]);
            } else {
                averages[i] = 0;
                System.out.println("No donors in age group " + groupNames[i]);
            }
        }

        System.out.println("\nGraph of Number of Donors by Age Group:");
        System.out.println("Number of Donors (Y) vs Age Group (X)\n");

        int maxDonors = 0;
        for (int countGroup : ageGroupCounts) {
            if (countGroup > maxDonors) {
                maxDonors = countGroup;
            }
        }

        System.out.println("Numbers Of Donors");
        for (int y = maxDonors; y >= 1; y--) {
            System.out.printf("%2d | ", y);
            for (int x = 0; x < ageGroupCounts.length; x++) {
                if (ageGroupCounts[x] >= y) {
                    System.out.print("   *   ");
                } else {
                    System.out.print("          ");
                }
            }
            System.out.println();
        }

        System.out.println("    ---------------------------------> Age Groups");
        System.out.println("     " + String.join("   ", groupNames));
        System.out.println("");
    }

    private void displayDonorGroup(SortedDoublyLinkedList<Donor> donors) {
        System.out.println("+======================================================================+");
        System.out.printf("|%-7s %-20s %-15s %-5s %-8s %-10s|\n", "ID", "Name", "Phone", "Age", "Gender", "Category");
        System.out.println("+======================================================================+");
        Iterator<Donor> iterator = donors.getIterator();
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            System.out.printf("|%-7s %-20s %-15s %-5d %-8s %-10s|\n",
                    donor.getDonorId(), donor.getName(), donor.getContactNo(),
                    donor.getDonorAge(), donor.getDonorGender(), donor.getDonorType());
        }
        System.out.println("────────────────────────────────────────────");
        System.out.println("Total Number of Donors in this Age Group: " + donors.getNumberOfEntries());
        System.out.println("");

//        System.out.println("Average of different Age group : ");
//        System.out.println("--------------------------------------");
    }

    private Donor searchDonor() {
        Donor foundDonor = null;

        while (foundDonor == null) {
            String find = donorUI.inputSearchDetails();

            // Check if the user wants to exit
            if (find.equals("0")) {
                System.out.println("Exiting search donor operation.");
                return null;
            }

            Iterator<Donor> iterator = donorList.getIterator();

            while (iterator.hasNext()) {
                Donor donor = iterator.next();
                if (donor.getDonorId().equals(find) || donor.getName().equalsIgnoreCase(find)) {
                    foundDonor = donor;
                    break;
                }
            }

            // If donor is not found, display not found message
            if (foundDonor == null) {
                MessageUI.displayNotFoundMessage();
                System.out.println("Please try again or enter 0 to exit.");
            }
        }

        return foundDonor;
    }

    private void removeDonor() {
        Donor donorToRemove = null;

        while (donorToRemove == null) {
            displayDonor();
            donorToRemove = searchDonor();

            if (donorToRemove == null) {
                donorToRemove = searchDonor();
                String userInput = scanner.nextLine().trim().toUpperCase();

                if (userInput.equals("0")) {
                    System.out.println("Exiting remove donor operation.");
                    return;
                }
            } else {
                System.out.println(donorToRemove);
                int confirm = donorUI.confirmOperation();

                if (confirm == 1) {
                    donorList.remove(donorToRemove);
                    MessageUI.displaySuccessfulDeleteMessage();
                } else {
                    MessageUI.displayUnsuccessfulDeleteMessage();
                }
                break;
            }
        }
        displayDonor();
    }

    private String searchDonor1() {
        String outputStr = "";
        String find = donorUI.inputSearchDetails();
        Donor foundDonor = null;
        Iterator<Donor> iterator = donorList.getIterator();
        int found = 0;
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            if (donor.getDonorId().equals(find) || donor.getName().equals(find)) {
                found = 1;
                foundDonor = donor;
            }

        }
        if (found == 1) {
            outputStr += foundDonor.toString();

            return outputStr;
        }
        MessageUI.displayNotFoundMessage();
        System.out.println("");
        return null;
    }

    //case 3 update donor
    private void updateDonor() {
        while (true) {
            displayDonor();
            Donor donorToUpdate = searchDonor();

            if (donorToUpdate != null) {
                System.out.println(donorToUpdate);
                int confirm = donorUI.confirmOperation();

                if (confirm == 1) {
                    Donor updatedDonor = donorUI.inputDonorDetailsU(donorToUpdate.getDonorId());

                    donorList.replace(donorToUpdate, updatedDonor);

                    MessageUI.displayUpdateSuccessfulMessage();
                } else {
                    MessageUI.displayUpdateUnsuccessfulMessage();
                }
                break;
            } else {
                System.out.println("Donor not found. Please try again or enter 0 to exit.");
                String userInput = scanner.nextLine().trim();
                if (userInput.equals("0")) {
                    break;
                }
            }
        }
    }

    //case 4 search donor
    private void searchDonors() {
        donorUI.listAllDonor(searchDonor1());
    }

    public void displayDonor() {
        SortedDoublyLinkedList<Donor> allDonors = new SortedDoublyLinkedList<>();

        Iterator<Donor> iterator = donorList.getIterator();
        while (iterator.hasNext()) {
            allDonors.add(iterator.next());
        }

        displayDonorGroup(allDonors);
    }

    public void addNewDonor() {
        Donor newDonor = donorUI.inputDonorDetails();
        donorList.add(newDonor);
        System.out.println("");
        MessageUI.displaySuccessfulAddMessage();
        displayDonor();
    }

    public void closeScanner() {
        scanner.close();
    }

    public void generateReport() {
        Timestamp dateTime = new Timestamp(System.currentTimeMillis());
        String newDateTime = dateTime.toString().substring(0, 16);
        System.out.println("+======================================================================+");
        System.out.println("|        TUNKU ABDUL RAHMAN UNIVERSITY OF MANAGEMENT AND TECHNOLOGY    |");
        System.out.println("|        Donor Management Subsystem                                    |");
        System.out.println("|        Donor ANALYSIS REPORT                                         |");
        System.out.println("+======================================================================+");
        System.out.println("    Generated at : " + newDateTime);
        System.out.println("************************************************************************");
        System.out.println("");
        displayDonor();
        countDuplicateDonorTypes();
        calculateDonorTypeExtremes();
    }

    public void calculateDonorTypeExtremes() {
        String[] donorTypes = {"Government", "Public", "Private"};
        int[] donorTypeCounts = new int[donorTypes.length];

        Iterator<Donor> iterator = donorList.getIterator();
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            String donorType = donor.getDonorType();

            for (int i = 0; i < donorTypes.length; i++) {
                if (donorTypes[i].equals(donorType)) {
                    donorTypeCounts[i]++;
                    break;
                }
            }
        }

        int highestCount = Integer.MIN_VALUE;
        int lowestCount = Integer.MAX_VALUE;
        String highestDonorType = "";
        String lowestDonorType = "";

        for (int i = 0; i < donorTypes.length; i++) {
            if (donorTypeCounts[i] > highestCount) {
                highestCount = donorTypeCounts[i];
                highestDonorType = donorTypes[i];
            }
            if (donorTypeCounts[i] < lowestCount) {
                lowestCount = donorTypeCounts[i];
                lowestDonorType = donorTypes[i];
            }
        }

        System.out.println("Highest Donor Type: " + highestDonorType + " with [" + highestCount + "] donors");
        System.out.println("Lowest Donor Type: " + lowestDonorType + " with [" + lowestCount + "] donors");

        System.out.println("");
    }

    public void countDuplicateDonorTypes() {
        int count = 0;
        String[] donorTypes = {"Government", "Public", "Private"};
        int[] donorTypeCounts = new int[donorTypes.length];

        Iterator<Donor> iterator = donorList.getIterator();
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            String donorType = donor.getDonorType();

            for (int i = 0; i < donorTypes.length; i++) {
                if (donorTypes[i].equals(donorType)) {
                    donorTypeCounts[i]++;
                    break;
                }
            }
        }

        System.out.println("Duplicate Donor Types : ");
        System.out.println("-----------------------");
        for (int i = 0; i < donorTypes.length; i++) {
            if (donorTypeCounts[i] > 1) {
                count++;
                System.out.println("" + count + "." + donorTypes[i] + ": " + donorTypeCounts[i] + " donors");
            }
        }
        System.out.println("");

        System.out.println("Graph of Donor Types : ");
        System.out.println("-----------------------");
        System.out.println("");
        System.out.println("No of Donors");
        int maxDonors = 0;
        for (int donorCount : donorTypeCounts) {
            if (donorCount > maxDonors) {
                maxDonors = donorCount;
            }
        }

        for (int y = maxDonors; y >= 1; y--) {
            System.out.printf("%2d | ", y);
            for (int x = 0; x < donorTypes.length; x++) {
                if (donorTypeCounts[x] >= y) {
                    System.out.print("    *      ");
                } else {
                    System.out.print("           ");
                }
            }
            System.out.println();
        }

        System.out.println("---------------------------------------------->Donor Types");
        System.out.print("     ");
        for (String donorType : donorTypes) {
            System.out.printf("%-13s", donorType);
        }
        System.out.println("");
        System.out.println("");
    }

    public static void main(String args[]) {
        DonorMaintenance donorMaintenance = new DonorMaintenance();
        donorMaintenance.runDonorMaintenance();
    }
}
