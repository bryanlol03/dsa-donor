package boundry;

import adt.SortedDoublyLinkedList;
import adt.SortedLinkedListInterface;
import dao.DonorInitializer;
import entity.Donor;
import java.util.Scanner;
import utility.MessageUI;
import java.sql.Timestamp;
import java.util.Iterator;

/**
 *
 * @author User
 */
public class DonorMaintenanceUI {

    private SortedLinkedListInterface<Donor> donorList = new SortedDoublyLinkedList<>();
    Scanner scanner = new Scanner(System.in);
    private DonorInitializer dI = new DonorInitializer();
    private SortedLinkedListInterface<Donor> donors = new SortedDoublyLinkedList<>();

    public DonorMaintenanceUI() {
        dI = new DonorInitializer();
        donorList = dI.initializeDonor();
    }

    public int getMenuChoice() {
        Timestamp dateTime = new Timestamp(System.currentTimeMillis());
        String newDateTime = dateTime.toString().substring(0, 16); // extract date time with hour and min
        int choice = -1;
        while (true) {
            MessageUI.displayWelcomeMsg();
            System.out.println("    +========================================+");
            System.out.println("    |       Donor Management Subsystem       |");
            System.out.println("    |       Today is -> " + newDateTime + "     |");
            System.out.println("    +========================================+");
            System.out.println("    | 1. Add New Donor                       |");
            System.out.println("    | 2. Remove a Donor                      |");
            System.out.println("    | 3. Update Donor Details                |");
            System.out.println("    | 4. Search Donor Details                |");
            System.out.println("    | 5. List Donor with Donation            |");
            System.out.println("    | 6. Filter Donor Based on Type          |");
            System.out.println("    | 7. Generate Report                     |");
            System.out.println("    | 0. Exit System                         |");
            System.out.println("    +----------------------------------------+\n");
            System.out.print("      Enter your choice --> ");
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 0 && choice <= 7) {
                    break;
                } else {
                    MessageUI.displayInvalidChoiceMessage();
                }
            } catch (NumberFormatException ex) {
                MessageUI.displayInvalidChoiceMessage();
            }
        }

        return choice;
    }

    public String inputDonorId() {
        String donorId;
        boolean isValid;

        do {
            System.out.print("  Enter Donor ID: ");
            donorId = scanner.nextLine().trim().toUpperCase();
            isValid = true;

            if (donorId.isEmpty()) {
                System.out.println("Invalid id the input should not be empty !");
                isValid = false;
                continue;
            }
            // Check if the ID starts with 'D'
            if (!donorId.startsWith("D")) {
                System.out.println("Invalid ID: Donor ID must start with 'D'. Please try again.");
                isValid = false;
                continue;
            }

            // Check if the ID length is not longer than 5 characters
            if (donorId.length() > 5) {
                System.out.println("Invalid ID: Donor ID must not be longer than 5 characters. Please try again.");
                isValid = false;
                continue;
            }

            // Check for duplicate ID in donorList
            Iterator<Donor> iterator = donorList.getIterator();
            while (iterator.hasNext()) {
                Donor donor = iterator.next();
                if (donor.getDonorId().equals(donorId)) {
                    System.out.println("Invalid ID: Duplicate Donor ID found in the list. Please enter a unique ID.");
                    isValid = false;
                    break;
                }
            }

        } while (!isValid);

        return donorId;
    }

    public String inputDonorName() {
        String name = null;
        boolean isValid;

        do {
            try {
                System.out.print("  Enter Donor Name: ");
                name = scanner.nextLine().trim().toUpperCase();
                isValid = validateName(name);
                if (!isValid) {
                    System.out.println("Invalid name. The name cannot contain numbers, special characters, or be empty!\n");
                }
            } catch (NullPointerException ex) {
                MessageUI.displayInvalidInputMessage();
                isValid = false; // Continue the loop if an exception occurs
            }
        } while (!isValid);

        return name;
    }

    private boolean validateName(String name) {
        String regex = "^[A-Za-z\\s]+$";
        return name != null && name.matches(regex) && !name.trim().isEmpty();
    }

    public String inputContact() {
        String contact;
        while (true) {
            System.out.print("  Enter Donor Contact Number (10 digits): ");
            contact = scanner.nextLine().trim();

            if (contact.isEmpty()) {
                System.out.println("  Contact cannot be empty!");
            } else if (validateContactNumber(contact) && !isContactNumberDuplicate(contact)) {
                break;
            } else if (!validateContactNumber(contact)) {
                System.out.println("  Invalid contact number. Please enter a valid 10-digit contact number.");
            } else {
                System.out.println("  This contact number is already in use. Please enter a unique contact number.");
            }
        }
        return contact;
    }

    private boolean validateContactNumber(String contact) {
        return contact.matches("\\d{10}");
    }

    private boolean isContactNumberDuplicate(String contact) {
        Iterator<Donor> iterator = donorList.getIterator();
        while (iterator.hasNext()) {
            Donor donor = iterator.next();
            if (donor.getContactNo().equals(contact)) {
                return true; // Duplicate found
            }
        }
        return false;
    }

    public String inputType() {
        String donorType;

        while (true) {
            System.out.print("  Enter Donor type (G - Government | P - Public | I - Private): ");
            try {
                String input = scanner.nextLine().trim().toUpperCase();

                if (input.length() != 1) {
                    System.out.println("  Invalid input. Please enter a single character (G, P, or I).");
                    continue;
                }

                char inputType = input.charAt(0);

                switch (inputType) {
                    case 'G':
                        donorType = "Government";
                        break;
                    case 'P':
                        donorType = "Public";
                        break;
                    case 'I':
                        donorType = "Private";
                        break;
                    default:
                        System.out.println("  Invalid input. Please enter 'G', 'P', or 'I'.");
                        continue;
                }

                break;
            } catch (Exception ex) {
                System.out.println("  An error occurred. Please try again.");
            }
        }

        return donorType;
    }

    public char inputGender() {
        char gender = '\0';
        boolean isValid = false;

        do {
            try {
                System.out.print("  Enter Donor Gender (M = Male | F = Female): ");
                String input = scanner.nextLine().trim();
                if (input.length() == 1) {
                    gender = Character.toUpperCase(input.charAt(0));
                    if (gender == 'M' || gender == 'F') {
                        isValid = true;
                    } else {
                        System.out.println("Invalid input. Please enter 'M' for Male or 'F' for Female.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a single character.");
                }
            } catch (NullPointerException ex) {
                System.out.println("Invalid input. Please try again.");
            }
        } while (!isValid);

        return gender;
    }

    public int inputAge() {
        int age = -1;
        while (true) {
            System.out.print("  Enter Donor Age (18 or older): ");
            try {
                String input = scanner.nextLine().trim();

                if (input.isEmpty()) {
                    System.out.println("  Age cannot be empty. Please enter a valid age.");
                    continue;
                }
                age = Integer.parseInt(input);

                if (age < 18) {
                    System.out.println("  Your age should be 18 or older!");
                } else {
                    break;
                }
            } catch (NumberFormatException ex) {
                System.out.println("  Invalid input. Please enter a valid age.");
            }
        }
        return age;
    }

    public Donor inputDonorDetailsU(String existingDonorID) {
        
        System.out.println("Donor ID: " + existingDonorID);
        String donorID = existingDonorID; 

        String donorName = inputDonorName().toUpperCase();
        int age = inputAge();
        String phone = inputContact();
        String type = inputType();
        char gender = inputGender();

        System.out.println();
        return new Donor(donorID, donorName, phone, age, gender, type);
    }

    public Donor inputDonorDetails() {
        String donorID = inputDonorId().toUpperCase();
        String donorName = inputDonorName().toUpperCase();
        int age = inputAge();
        String phone = inputContact();
        String type = inputType();
        char gender = inputGender();
        System.out.println();
        return new Donor(donorID, donorName, phone, age, gender, type);
    }

    public void listAllDonor(String outputStr) {
        if (outputStr != null) {
            System.out.println("Donor Details");
            System.out.println("+======================================================================+");
            System.out.printf("|%-7s %-12s %-12s %-6s %-7s %-10s           |\n", "Id", "Name", "Phone", "Age", "Gender", "Type");
            System.out.println("+======================================================================+");
            System.out.println(outputStr);
        }
    }

    //remove method 
    public int confirmOperation() {
        int confirm = 0;
        boolean isValid = false;

        while (!isValid) {
            try {
                System.out.print("Confirm your Operation? (1 = YES / 2 = NO): ");
                confirm = scanner.nextInt();
                scanner.nextLine();

                if (confirm == 1 || confirm == 2) {
                    isValid = true;
                } else {
                    MessageUI.displayInvalidChoiceMessage();
                }
            } catch (java.util.InputMismatchException e) {
                MessageUI.displayInvalidChoiceMessage();
                scanner.nextLine();
            }
        }

        return confirm;
    }

    public String inputSearchDetails() {
        System.out.print("Enter Donor ID or Name: ");
        String input = scanner.nextLine().trim().toUpperCase();
        return input;
    }

    public int inputMinAge() {
        int age = -1;
        while (true) {
            System.out.print("Enter the minimum age: ");
            String input = scanner.nextLine().trim();

            if (input.isEmpty()) {
                System.out.println("Input cannot be empty. Please enter a valid age.");
                continue;
            }

            try {
                age = Integer.parseInt(input);
                if (age >= 0) {
                    break;
                } else {
                    System.out.println("Age must be a non-negative integer.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
        return age;
    }

    public int inputMaxAge() {
        int age = -1;
        while (true) {
            System.out.print("Enter the maximum age: ");
            String input = scanner.nextLine().trim();

            if (input.isEmpty()) {
                System.out.println("Input cannot be empty. Please enter a valid age.");
                continue;
            }

            try {
                age = Integer.parseInt(input);
                if (age >= 0) {
                    break;
                } else {
                    System.out.println("Age must be a non-negative integer.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
        return age;
    }

    public void closeScanner() {
        scanner.close();
    }
}
